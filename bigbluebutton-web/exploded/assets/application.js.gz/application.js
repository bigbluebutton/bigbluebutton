//# sourceMappingURL=application.js.map
var process=process||{env:{NODE_ENV:"development"}};