//# sourceMappingURL=webjars-requirejs.js.map
var process=process||{env:{NODE_ENV:"development"}};requirejs.config({paths:{jquery:webjars.path("jquery","jquery")},shim:{jquery:{exports:"$"}}});